package com.company.myapp.dto;

import lombok.Data;

@Data
public class SampleDTO {
	private String id;
	private String pw;
}

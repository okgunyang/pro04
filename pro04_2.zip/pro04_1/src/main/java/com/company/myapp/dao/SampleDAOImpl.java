package com.company.myapp.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.company.myapp.dto.SampleDTO;

@Repository
public class SampleDAOImpl implements SampleDAO {
	@Autowired
	SqlSession sqlSession;
	
	@Override
	public List<SampleDTO> sampleList() throws Exception {
		return sqlSession.selectList("sample.sampleList");
	}

	@Transactional
	@Override
	public SampleDTO getSample(String id) throws Exception {
		sqlSession.update("sample.updateVcnt", id);
		return sqlSession.selectOne("sample.getSample", id);
	}
	
}
